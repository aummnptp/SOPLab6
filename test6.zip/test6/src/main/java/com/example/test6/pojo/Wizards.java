package com.example.test6.pojo;

import java.io.Serializable;
import java.util.ArrayList;

public class Wizards implements Serializable {
    ArrayList<Wizard> model = new ArrayList<Wizard>();

    public Wizards() {
    }
}